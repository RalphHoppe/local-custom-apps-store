Thanks for trying focus-flow!

This is a demo package. Replace this archive with your real installer in public/downloads, or update downloadUrl in public/apps.json.
